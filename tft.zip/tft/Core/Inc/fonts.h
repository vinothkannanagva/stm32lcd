#ifndef __FONT_H
#define __FONT_H

#include "stdint.h"

typedef struct {
    const uint8_t width;
    uint8_t height;
    const uint16_t *data;
} FontDef;

//Font lib.
extern FontDef Font_7x10;
extern FontDef Font_11x18;
extern FontDef Font_16x26;

//16-bit(RGB565) Image lib.
/*******************************************
 *             CAUTION:
 *   If the MCU onchip flash cannot
 *  store such huge image data,please
 *           do not use it.
 * These pics are for test purpose only.
 *******************************************/

/* 128x128 pixel RGB565 image */
extern const uint16_t saber[][128];
extern const uint16_t cap150 [] [150];
extern const uint16_t cap145 [] [145];
extern const uint16_t cap160 [] [160];
extern const uint16_t cap160_1 [] [160];
extern const uint16_t bmp [] [160];
extern const uint16_t cap170 [] [170];
extern const uint16_t cap180 [] [180];
extern const uint16_t saber1[][128];
// 240x240 pixel RGB565 image
extern const uint16_t knky[][240];
extern const uint16_t tek[][240];
extern const uint16_t adi1[][240];

#endif
